# Name: Gili Gutfeld, ID: 209284512

# -*- coding: utf-8 -*-
import csv
import math
import random
from ways import load_map_from_csv
from queue import PriorityQueue
from ways.info import SPEED_RANGES


NUMBER_OF_PROBLEMS = 100
NUMBER_OF_JUNCTIONS = 944800
DISTANCE_IN_PROBLEM = 20
METERS_IN_KILOMETER = 1000


# generate 100 random problems with source and destination junctions
def generate_problems(roads):
    index_list = []
    file = open('./problems.csv', 'w', newline='')
    writer = csv.writer(file)

    # generate 100 random junctions in the range
    for i in range(0, NUMBER_OF_PROBLEMS):
        index_list.append(random.randint(0, NUMBER_OF_JUNCTIONS))

    # for each junction create a path to another junction in length of 20
    for index in index_list:
        count = 0
        next_junction = 0
        links = roads[index][3]

        # get the 20th link
        while count < DISTANCE_IN_PROBLEM and len(links) != 0:
            link = links[0]
            next_junction = link[1]
            links = roads[next_junction][3]
            count += 1

        writer.writerow([index, next_junction])
    file.close()


def search_algorithm(source, dest, roads, algo):

    # initialize a priority queue with the source junction and distance 0
    open_list = PriorityQueue()
    open_list.put((0, [source]))
    close_list = []

    while not open_list.empty():

        # get the next path and put in a list all the last junctions at the paths
        current = open_list.get()
        closest_junctions = []
        for index in open_list.queue:
            closest_junctions.append(index[1][-1])

        # get the path, distance and last junction in the path
        current_path = current[1]
        current_junc = current_path[-1]
        current_dist = current[0]
        close_list.append(current_junc)

        # check if we arrived to the destination
        if current_junc == dest:
            estimated_time = h(roads[source], roads[dest])
            return current_path, current_dist, estimated_time

        # get the neighbors of the junction
        neighbors = roads[current_junc].links
        for neighbor in neighbors:

            # calculate the new cost to the neighbor
            new_distance = g(neighbor, current_dist)
            neighbor_index = neighbor.target
            if algo == 'astar':
                new_distance += h(roads[neighbor_index], roads[dest])

            new_path = list(current_path)

            # if the neighbor is not in the close_list or in the end of one of the paths add it to the path
            if neighbor_index not in close_list and neighbor_index not in closest_junctions:
                new_path.append(neighbor_index)
                open_list.put((new_distance, new_path))

            # if the neighbor is in the end of one of the paths check if we improved the path
            elif neighbor_index in closest_junctions:
                old_distance = 0
                for node in open_list.queue:
                    previous_index = node[1][-1]
                    if previous_index == neighbor_index:
                        old_distance = node[0]

                # if we find a shorter path update it
                if new_distance < old_distance:
                    new_path.append(neighbor_index)
                    open_list.put((new_distance, new_path))
    return None


def dfs_f(state, current_g, path, f_limit, destination, roads):
    global new_limit

    # calculate the new f and update the new limit if we found a better distance
    new_f = current_g + h(roads[state], roads[destination])
    if new_f > f_limit:
        new_limit = min(new_limit, new_f)
        return None

    # return the path when we arrive the destination
    if state == destination:
        return path

    # for each link call the dfs_f with the new path until we find the solution
    for link in roads[state].links:
        new_path = path.copy()
        new_path.append(link.target)
        solution = dfs_f(link.target, g(link, current_g), new_path, f_limit, destination, roads)
        if solution:
            return solution

    return None


# IDA Star algorithm
def ida_star(source, target):
    'call function to find path, and return list of indices'
    roads = load_map_from_csv()
    global new_limit

    # assign to the new limit the heuristic value between the source and the target
    new_limit = h(roads[source], roads[target])

    # loop until we find the solution
    while True:

        # put in the f_limit the new limit and then assign to the new limit infinity
        f_limit = new_limit
        new_limit = math.inf

        # call to dfs_f and return the solution if we found it
        solution = dfs_f(source, 0, [source], f_limit, target, roads)
        if solution:
            return solution


# get the new cost of the junction
def g(link, old_cost):
    distance = link.distance / METERS_IN_KILOMETER
    highway_type = link.highway_type
    addition = distance / SPEED_RANGES[highway_type][1]
    return old_cost + addition


# get the heuristic cost from the junction to the destination
def h(junction, destination):
    from main import huristic_function
    return huristic_function(junction.lat, junction.lon, destination.lat, destination.lon)


# solve the problems from the problems file
def solve_problems(algo, csv_file='problems.csv'):
    roads = load_map_from_csv()
    file = open(csv_file)
    csv_reader = csv.reader(file)

    # check which algo we need to run
    if algo == 'ucs':
        file_name = 'results/UCSRuns.txt'
        algo = 'ucs'
    elif algo == 'astar':
        file_name = 'results/AStarRuns.txt'
        algo = 'astar'

    # open a file to right the solution and run the algorithm for each row
    with open(file_name, 'w') as solutions:
        for row in csv_reader:
            solution = search_algorithm(source=int(row[0]), dest=int(row[1]), roads=roads, algo=algo)
            junctions = solution[0]

            # write the path of the solution
            for junction in junctions:
                solutions.write(str(junction) + ' ')
            solutions.write('- ' + format(solution[1], '.4f'))
            if algo == 'astar':
                solutions.write(" - " + format(solution[2], '.4f'))
            solutions.write('\n')

    file.close()
    solutions.close()

